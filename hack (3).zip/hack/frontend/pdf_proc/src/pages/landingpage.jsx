import React from "react";
import { Link } from "react-router-dom";
import Button from "../components/button";

const LandingPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-900 to-purple-900">
      {/* Navigation Bar */}
      <nav className="flex items-center justify-between px-10 py-8">
        <div className="text-3xl font-bold text-white">DocuMind AI</div>
        <div className="flex gap-6">
          <Link to="/login">
            <Button variant="ghost" className="text-white text-xl hover:text-indigo-200">
              Login
            </Button>
          </Link>
          <Link to="/signup">
            <Button className="bg-indigo-500 text-white px-10 py-4 text-2xl rounded-lg hover:bg-indigo-600">
              Sign Up
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="container mx-auto px-6 py-20 flex flex-col-reverse md:flex-row items-center justify-center text-center md:text-left min-h-screen">
        <div className="md:w-1/2 space-y-8 pl-16 flex flex-col items-start">
          {/* Moved h1 up by adding negative margin */}
          <h1 className="text-6xl font-extrabold text-white leading-tight mt-[-40px]">
            Transform Your <br /> Financial Data Processing
          </h1>

          {/* Added more space between paragraph and button */}
          <p className="text-2xl text-indigo-200 mb-8">
            Where AI meets financial document processing, turning complex PDFs into 
            structured data with precision and intelligence.
          </p>

          <Link to="/signup">
            <Button className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white px-12 py-6 text-2xl rounded-lg hover:from-indigo-600 hover:to-purple-600">
              Get Started 
            </Button>
          </Link>
        </div>

        <div className="md:w-1/2 flex justify-center pl-16">
          {/* Moved document icon up slightly */}
          <div className="w-96 h-96 bg-white/10 rounded-xl p-10 backdrop-blur-md flex flex-col items-center justify-center mt-[-30px]">
            <svg
              className="w-40 h-40 text-indigo-300"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm4 18H6V4h7v5h5v11z" />
              <path d="M10 13h4v4h-4z" />
            </svg>
            <div className="mt-6 space-y-3">
              <div className="h-4 w-48 bg-indigo-400/30 rounded"></div>
              <div className="h-4 w-32 bg-indigo-400/30 rounded"></div>
            </div>
          </div>
        </div>
      </main>

      {/* Features Section */}
      <section className="bg-white/10 py-24">
        <div className="container mx-auto px-6 grid md:grid-cols-3 gap-12 text-center">
          {[
            {
              title: "Intelligent Format Detection",
              description:
                "Automatically detects and classifies various PDF formats from different ERP systems."
            },
            {
              title: "Accurate Data Extraction",
              description:
                "Extract financial data with high precision using advanced ML algorithms."
            },
            {
              title: "Continuous Learning",
              description:
                "Improves accuracy over time through user feedback and machine learning."
            }
          ].map((feature, index) => (
            <div key={index} className="p-10 rounded-lg backdrop-blur-md bg-white/10">
              <h3 className="text-2xl font-semibold text-white mb-5">{feature.title}</h3>
              <p className="text-xl text-indigo-200">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
