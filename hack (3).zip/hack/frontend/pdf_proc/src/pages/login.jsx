import React, { useState } from 'react';
import { loginWithEmailAndPassword, auth, db } from '../components//firebase/firebase';
import { ref, get } from 'firebase/database';
import { useNavigate } from 'react-router-dom';
import Button from '../components/button';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const userCredential = await loginWithEmailAndPassword(formData.email, formData.password);
      const user = userCredential.user;

      // Fetch user data from Realtime Database
      const userRef = ref(db, 'users/' + user.uid);
      const snapshot = await get(userRef);
      if (snapshot.exists()) {
        console.log('User data:', snapshot.val());
        navigate('/dashboard'); // Redirect to the dashboard
      } else {
        setError('User data not found. Please try again.');
      }
    } catch (error) {
      console.error('Login error:', error);
      setError(error.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-900 to-purple-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white/10 backdrop-blur-lg rounded-xl p-8 shadow-xl">
        <h2 className="text-3xl font-bold text-white mb-6 text-center">Welcome Back</h2>
        <p className="text-indigo-200 text-center mb-8">Enter your credentials to access your account</p>

        {error && <p className="text-red-500 text-center">{error}</p>}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-indigo-200 mb-2">Email</label>
            <input
              type="email"
              className="w-full px-4 py-2 bg-white/5 border border-indigo-200/20 rounded-lg text-white placeholder-indigo-200/50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="your@email.com"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-indigo-200 mb-2">Password</label>
            <input
              type="password"
              className="w-full px-4 py-2 bg-white/5 border border-indigo-200/20 rounded-lg text-white placeholder-indigo-200/50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="••••••••"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
            />
          </div>

          <Button className="w-full">Sign In</Button>
        </form>
      </div>
    </div>
  );
};

export default Login;
