import React, { useState } from 'react';
import { registerWithEmailAndPassword, auth, db } from '../components/firebase/firebase';
import { ref, set } from 'firebase/database';
import { useNavigate } from 'react-router-dom';
import Button from '../components/button';

const Signup = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match!');
      return;
    }
    try {
      const userCredential = await registerWithEmailAndPassword(formData.email, formData.password);
      const user = userCredential.user;

      // Store user data in Firebase Realtime Database
      await set(ref(db, 'users/' + user.uid), {
        fullName: formData.fullName,
        email: formData.email,
      });

      console.log('User registered:', user);
      navigate('/login'); // Redirect to login page
    } catch (error) {
      console.error('Signup error:', error);
      setError(error.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-900 to-purple-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white/10 backdrop-blur-lg rounded-xl p-8 shadow-xl">
        <h2 className="text-3xl font-bold text-white mb-6 text-center">Create Account</h2>
        <p className="text-indigo-200 text-center mb-8">Join us to automate your PDF processing</p>

        {error && <p className="text-red-500 text-center">{error}</p>}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-indigo-200 mb-2">Full Name</label>
            <input
              type="text"
              className="w-full px-4 py-2 bg-white/5 border border-indigo-200/20 rounded-lg text-white placeholder-indigo-200/50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="John Doe"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-indigo-200 mb-2">Email</label>
            <input
              type="email"
              className="w-full px-4 py-2 bg-white/5 border border-indigo-200/20 rounded-lg text-white placeholder-indigo-200/50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="your@email.com"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-indigo-200 mb-2">Password</label>
            <input
              type="password"
              className="w-full px-4 py-2 bg-white/5 border border-indigo-200/20 rounded-lg text-white placeholder-indigo-200/50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="••••••••"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-indigo-200 mb-2">Confirm Password</label>
            <input
              type="password"
              className="w-full px-4 py-2 bg-white/5 border border-indigo-200/20 rounded-lg text-white placeholder-indigo-200/50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="••••••••"
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              required
            />
          </div>

          <Button className="w-full">Create Account</Button>
        </form>
      </div>
    </div>
  );
};

export default Signup;
