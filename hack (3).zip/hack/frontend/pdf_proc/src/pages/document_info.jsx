import React, { useState } from 'react';
import { FileText, Download, MessageCircle, X, ThumbsUp, ThumbsDown, Send, Edit, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '../components/card';

const DocumentViewer = () => {
  // Keeping all the original state and handlers
  const [showChat, setShowChat] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [messageInput, setMessageInput] = useState('');
  const [showFeedback, setShowFeedback] = useState(false);
  const [confidenceScore] = useState(75);
  const [feedbackRating, setFeedbackRating] = useState(null);
  const [feedbackText, setFeedbackText] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  const documentData = {
    id: 1,
    name: 'Financial_Report_Q4.pdf',
    uploadedBy: 'John Doe',
    date: '2025-02-13',
    size: '2.4 MB',
    type: 'Financial',
    category: 'Invoice',
    confidence: confidenceScore,
    content: 'Sample document content...'
  };

  const handleChatSubmit = (e) => {
    e.preventDefault();
    if (!messageInput.trim()) return;
  
    setChatMessages((prevMessages) => [
      ...prevMessages,
      { text: messageInput, sender: 'user' },
      { text: 'Thank you for your message. I\'ll help you with that.', sender: 'bot' }
    ]);
    setMessageInput('');
  };

  const handleFeedbackSubmit = () => {
    console.log('Feedback submitted:', { rating: feedbackRating, text: feedbackText });
    setShowFeedback(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50">
      {/* Enhanced Header */}
      <div className="bg-white/80 border-b border-indigo-100 backdrop-blur-lg sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Document Viewer
          </h1>
          <p className="text-indigo-600 mt-1 font-medium">{documentData.name}</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Document Preview */}
            <Card className="border border-indigo-100 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="border-b border-indigo-100">
                <CardTitle className="text-indigo-900">Document Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg p-8 min-h-[600px] flex items-center justify-center">
                  <FileText size={48} className="text-indigo-400" />
                </div>
              </CardContent>
            </Card>

            {/* Export Options */}
            <Card className="border border-indigo-100 shadow-md hover:shadow-lg transition-all">
              <CardHeader className="border-b border-indigo-100">
                <CardTitle className="text-indigo-900">Export Options</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <button className="w-full flex items-center justify-center px-4 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all shadow-sm">
                  <Download className="w-4 h-4 mr-2" />
                  Download Structured Excel/CSV
                </button>
              </CardContent>
            </Card>

            {/* Enhanced Feedback Section */}
            {showFeedback && (
              <Card className="relative animate-in slide-in-from-bottom duration-300 border border-indigo-100 shadow-lg">
                <button 
                  onClick={() => setShowFeedback(false)}
                  className="absolute top-4 right-4 p-2 hover:bg-indigo-50 rounded-full transition-colors"
                >
                  <X className="w-4 h-4 text-indigo-600" />
                </button>
                <CardHeader className="border-b border-indigo-100">
                  <CardTitle className="text-indigo-900">Provide Feedback</CardTitle>
                  <CardDescription className="text-indigo-600">Help us improve our document processing</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-center space-x-4">
                    <button 
                      onClick={() => setFeedbackRating('positive')}
                      className={`p-3 rounded-full transition-all ${
                        feedbackRating === 'positive' 
                          ? 'bg-emerald-100 text-emerald-600 scale-110' 
                          : 'hover:bg-indigo-50 text-indigo-600'
                      }`}
                    >
                      <ThumbsUp className="w-6 h-6" />
                    </button>
                    <button 
                      onClick={() => setFeedbackRating('negative')}
                      className={`p-3 rounded-full transition-all ${
                        feedbackRating === 'negative' 
                          ? 'bg-red-100 text-red-600 scale-110' 
                          : 'hover:bg-indigo-50 text-indigo-600'
                      }`}
                    >
                      <ThumbsDown className="w-6 h-6" />
                    </button>
                  </div>
                  <textarea
                    placeholder="Please provide additional feedback..."
                    className="w-full p-3 rounded-lg border border-indigo-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/50"
                    rows={4}
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                  />
                  <button 
                    onClick={handleFeedbackSubmit}
                    className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all shadow-sm"
                  >
                    Submit Feedback
                  </button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Enhanced Sidebar */}
          <div className="space-y-6">
            {/* Document Info */}
            <Card className="border border-indigo-100 shadow-md hover:shadow-lg transition-all">
              <CardHeader className="border-b border-indigo-100">
                <CardTitle className="text-indigo-900">Document Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-indigo-600">Category</p>
                  <p className="font-medium text-indigo-900">{documentData.category}</p>
                </div>
                <div>
                  <p className="text-sm text-indigo-600">Confidence Score</p>
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 bg-indigo-100 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${
                          confidenceScore >= 80 
                            ? 'bg-gradient-to-r from-emerald-500 to-teal-500' 
                            : 'bg-gradient-to-r from-amber-500 to-orange-500'
                        }`}
                        style={{ width: `${confidenceScore}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium text-indigo-900">{confidenceScore}%</span>
                  </div>
                </div>
                {confidenceScore < 80 && (
                  <button 
                    onClick={() => setIsEditing(!isEditing)}
                    className="flex items-center space-x-2 text-indigo-600 hover:text-indigo-700"
                  >
                    <Edit className="w-4 h-4" />
                    <span>Edit Document</span>
                  </button>
                )}
                <button 
                  onClick={() => setShowFeedback(true)}
                  className="w-full flex items-center justify-center px-4 py-2 border border-indigo-200 rounded-lg hover:bg-indigo-50 transition-all text-indigo-600"
                >
                  Provide Feedback
                </button>
              </CardContent>
            </Card>

            {/* Additional Info */}
            <Card className="border border-indigo-100 shadow-md">
              <CardContent className="p-4">
                <div className="flex items-start space-x-3 text-amber-700 bg-amber-50 rounded-lg p-3">
                  <AlertCircle className="w-5 h-5 mt-0.5" />
                  <p className="text-sm">
                    {confidenceScore < 80 
                      ? "This document's confidence score is below 80%. Please review and edit if necessary." 
                      : "This document has been processed with high confidence."}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Enhanced Chat Widget */}
      <div className="fixed bottom-6 right-6 z-50">
        {showChat ? (
          <Card className="w-80 h-96 flex flex-col animate-in slide-in-from-bottom duration-300 border border-indigo-100 shadow-2xl">
            <CardHeader className="border-b border-indigo-100">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-indigo-900">Chat Support</CardTitle>
                <button 
                  onClick={() => setShowChat(false)}
                  className="p-2 hover:bg-indigo-50 rounded-full transition-colors"
                >
                  <X className="w-4 h-4 text-indigo-600" />
                </button>
              </div>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto p-4">
              <div className="space-y-4">
                {chatMessages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg px-4 py-2 ${
                        message.sender === 'user'
                          ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                          : 'bg-indigo-50 text-indigo-900'
                      }`}
                    >
                      {message.text}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter className="border-t border-indigo-100 p-4">
              <form onSubmit={handleChatSubmit} className="w-full flex space-x-2">
                <input
                  type="text"
                  placeholder="Type a message..."
                  className="flex-1 px-3 py-2 border border-indigo-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white/50"
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                />
                <button
                  type="submit"
                  className="p-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </CardFooter>
          </Card>
        ) : (
          <button
            onClick={() => setShowChat(true)}
            className="p-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-full shadow-lg hover:from-indigo-700 hover:to-purple-700 transition-all"
          >
            <MessageCircle className="w-6 h-6" />
          </button>
        )}
      </div>
    </div>
  );
};

export default DocumentViewer;