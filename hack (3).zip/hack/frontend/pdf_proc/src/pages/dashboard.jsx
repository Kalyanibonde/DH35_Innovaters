import React, { useState, useEffect } from 'react';
import { Upload, FileText, Bell, Search, Settings, ChevronDown, X, ThumbsUp, ThumbsDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/card';

const Dashboard = () => {
  // Original state
  const [isDragging, setIsDragging] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);
  const [extractedText, setExtractedText] = useState('');
  const [extractedEntities, setExtractedEntities] = useState({});
  const [excelFilename, setExcelFilename] = useState('');

  // New state for feedback and confidence
  const [showFeedback, setShowFeedback] = useState(false);
  const [confidenceScore, setConfidenceScore] = useState(75);
  const [feedbackRating, setFeedbackRating] = useState(null);
  const [feedbackText, setFeedbackText] = useState('');

  // Original handlers
  const handleFileSelect = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleDrop = (event) => {
    event.preventDefault();
    setIsDragging(false);
    if (event.dataTransfer.files.length) {
      setSelectedFile(event.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (event) => {
    event.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      alert('Please select a file first!');
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      const response = await fetch('http://localhost:5000/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();
      setExtractedText(data.text);
      setExtractedEntities(data.entities);
      if (data.tables_extracted && data.excel_filename) {
        setExcelFilename(data.excel_filename);
      } else {
        setExcelFilename('');
      }
      
      // Set confidence score from backend response
      if (data.confidence_score) {
        setConfidenceScore(data.confidence_score);
      }
    } catch (error) {
      console.error('Error uploading file:', error);
    }
  };

  const handleDownloadExcel = () => {
    if (!excelFilename) {
      console.error('Excel filename is missing:', excelFilename);
      alert('No Excel file generated yet! Please check the backend response.');
      return;
    }
    
    const timestamp = new Date().getTime();
    const queryFilename = excelFilename;
    window.location.href = `http://localhost:5000/download_excel?filename=${queryFilename}&t=${timestamp}`;
  };

  // New handler for feedback submission
  const handleFeedbackSubmit = () => {
    console.log('Feedback submitted:', { rating: feedbackRating, text: feedbackText });
    // Here you can add API call to submit feedback
    setShowFeedback(false);
    setFeedbackRating(null);
    setFeedbackText('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50">
      {/* Existing Navbar */}
      <nav className="bg-white border-b border-indigo-100 shadow-sm backdrop-blur-lg bg-white/80">
        {/* ... (keeping existing navbar code) ... */}
      </nav>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Upload Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div 
              className={`mb-8 rounded-xl border-2 border-dashed ${
                isDragging ? 'border-indigo-400 bg-indigo-50' : 'border-indigo-200 bg-white'
              } transition-all duration-200 shadow-lg hover:shadow-xl`}
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
            >
              <div className="text-center py-12">
                <Upload size={48} className="mx-auto mb-4 text-indigo-400" />
                <h3 className="text-xl font-semibold mb-2 text-indigo-900">Drop your PDF files here</h3>
                <p className="text-indigo-600 mb-4">or</p>
                <input type="file" className="hidden" id="fileInput" onChange={handleFileSelect} />
                <label 
                  htmlFor="fileInput" 
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all shadow-sm cursor-pointer font-medium"
                >
                  Browse Files
                </label>
              </div>
              {selectedFile && (
                <p className="text-center text-sm text-indigo-600 pb-4">
                  Selected file: {selectedFile.name}
                </p>
              )}
            </div>

            {/* Upload Button */}
            <div className="flex justify-center mb-6">
              <button
                onClick={handleUpload}
                className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-lg hover:from-emerald-600 hover:to-teal-600 transition-all shadow-sm cursor-pointer font-medium"
              >
                Upload & Extract
              </button>
            </div>

            {/* Extracted Content */}
            {extractedText && (
              <div className="bg-white p-6 rounded-xl shadow-lg border border-indigo-100">
                <h3 className="text-lg font-semibold mb-4 text-indigo-900">Extracted Text:</h3>
                <p className="text-indigo-800 whitespace-pre-wrap bg-indigo-50/50 p-4 rounded-lg">
                  {extractedText}
                </p>

                <h3 className="text-lg font-semibold mt-6 mb-4 text-indigo-900">Extracted Entities:</h3>
                <pre className="text-indigo-800 bg-indigo-50/50 p-4 rounded-lg overflow-auto">
                  {JSON.stringify(extractedEntities, null, 2)}
                </pre>
              </div>
            )}

            {/* Download Excel Button */}
            {extractedText && (
              <div className="flex justify-center mt-6">
                <button
                  onClick={handleDownloadExcel}
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all shadow-sm cursor-pointer font-medium"
                >
                  Download as Excel
                </button>
              </div>
            )}
          </div>

          {/* Sidebar with Confidence Score and Feedback */}
          <div className="space-y-6">
            {extractedText && (
              <Card className="border border-indigo-100 shadow-md hover:shadow-lg transition-all">
                <CardHeader className="border-b border-indigo-100">
                  <CardTitle className="text-indigo-900">Document Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-indigo-600">Confidence Score</p>
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 bg-indigo-100 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            confidenceScore >= 80 
                              ? 'bg-gradient-to-r from-emerald-500 to-teal-500' 
                              : 'bg-gradient-to-r from-amber-500 to-orange-500'
                          }`}
                          style={{ width: `${confidenceScore}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium text-indigo-900">{confidenceScore}%</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => setShowFeedback(true)}
                    className="w-full flex items-center justify-center px-4 py-2 border border-indigo-200 rounded-lg hover:bg-indigo-50 transition-all text-indigo-600"
                  >
                    Provide Feedback
                  </button>
                </CardContent>
              </Card>
            )}

            {/* Feedback Modal */}
            {showFeedback && (
              <Card className="relative animate-in slide-in-from-bottom duration-300 border border-indigo-100 shadow-lg">
                <button 
                  onClick={() => setShowFeedback(false)}
                  className="absolute top-4 right-4 p-2 hover:bg-indigo-50 rounded-full transition-colors"
                >
                  <X className="w-4 h-4 text-indigo-600" />
                </button>
                <CardHeader className="border-b border-indigo-100">
                  <CardTitle className="text-indigo-900">Provide Feedback</CardTitle>
                  <CardDescription className="text-indigo-600">Help us improve our document processing</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-center space-x-4">
                    <button 
                      onClick={() => setFeedbackRating('positive')}
                      className={`p-3 rounded-full transition-all ${
                        feedbackRating === 'positive' 
                          ? 'bg-emerald-100 text-emerald-600 scale-110' 
                          : 'hover:bg-indigo-50 text-indigo-600'
                      }`}
                    >
                      <ThumbsUp className="w-6 h-6" />
                    </button>
                    <button 
                      onClick={() => setFeedbackRating('negative')}
                      className={`p-3 rounded-full transition-all ${
                        feedbackRating === 'negative' 
                          ? 'bg-red-100 text-red-600 scale-110' 
                          : 'hover:bg-indigo-50 text-indigo-600'
                      }`}
                    >
                      <ThumbsDown className="w-6 h-6" />
                    </button>
                  </div>
                  <textarea
                    placeholder="Please provide additional feedback..."
                    className="w-full p-3 rounded-lg border border-indigo-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/50"
                    rows={4}
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                  />
                  <button 
                    onClick={handleFeedbackSubmit}
                    className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all shadow-sm"
                  >
                    Submit Feedback
                  </button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;