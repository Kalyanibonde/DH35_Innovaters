import { useState } from 'react'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Dashboard from './pages/dashboard';
import Documentinfo from './pages/document_info'
import LandingPage from './pages/landingpage';
import LoginPage from "./pages/login";
import SignupPage from "./pages/signup";


function App() {
  return (
    <Router>
      <Routes>
      <Route path="/" element={<LandingPage/>} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/document" element={<Documentinfo />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
      </Routes>
      </Router>
      
  );
}

export default App;
