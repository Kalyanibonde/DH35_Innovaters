// firebase.js
import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider } from "firebase/auth"; 
import { getDatabase } from "firebase/database";

const firebaseConfig = {
    apiKey: "AIzaSyC_pmrFtrM9jEiCigVsijgqnhgi9y5Co_k",
  authDomain: "pdf-reader-bbf15.firebaseapp.com",
  databaseURL: "https://pdf-reader-bbf15-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "pdf-reader-bbf15",
  storageBucket: "pdf-reader-bbf15.firebasestorage.app",
  messagingSenderId: "401704072963",
  appId: "1:401704072963:web:e9a71b20f9ce9ff8ac9b36",
  measurementId: "G-Z8D5KVGF5F"
  };
  
// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and Realtime Database
const auth = getAuth(app);
const db = getDatabase(app);

// Google Auth Provider (for Google sign-in)
const googleProvider = new GoogleAuthProvider();

// Functions for Email/Password Authentication
const registerWithEmailAndPassword = (email, password) => {
  return createUserWithEmailAndPassword(auth, email, password);
};

const loginWithEmailAndPassword = (email, password) => {
  return signInWithEmailAndPassword(auth, email, password);
};

// Function for Google Authentication
const signInWithGoogle = () => {
  return signInWithPopup(auth, googleProvider);
};

// Export all necessary components
export { app, auth, db, registerWithEmailAndPassword, loginWithEmailAndPassword, signInWithGoogle };
