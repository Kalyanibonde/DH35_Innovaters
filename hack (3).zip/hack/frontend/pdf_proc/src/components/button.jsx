// Button.js
import React from 'react';

const Button = React.forwardRef(({ 
  className = '',
  variant = 'default',
  size = 'default',
  children,
  ...props 
}, ref) => {
  const baseStyles = 'inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-indigo-400 disabled:pointer-events-none disabled:opacity-50';
  
  const variants = {
    default: 'bg-indigo-500 text-white hover:bg-indigo-600',
    destructive: 'bg-red-500 text-white hover:bg-red-600',
    outline: 'border border-indigo-200 bg-transparent hover:bg-indigo-100 hover:text-indigo-900',
    secondary: 'bg-indigo-200 text-indigo-900 hover:bg-indigo-300',
    ghost: 'text-white hover:bg-white/10',
    link: 'text-indigo-900 underline-offset-4 hover:underline',
  };

  const sizes = {
    default: 'h-9 px-4 py-2',
    sm: 'h-8 rounded-md px-3 text-xs',
    lg: 'h-10 rounded-md px-8',
    icon: 'h-9 w-9',
  };

  const classes = `${baseStyles} ${variants[variant] || variants.default} ${sizes[size] || sizes.default} ${className}`;

  return (
    <button
      className={classes}
      ref={ref}
      {...props}
    >
      {children}
    </button>
  );
});

Button.displayName = 'Button';

export default Button;